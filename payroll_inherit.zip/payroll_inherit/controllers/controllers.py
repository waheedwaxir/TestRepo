# -*- coding: utf-8 -*-
# from odoo import http


# class PayrollInherit(http.Controller):
#     @http.route('/payroll_inherit/payroll_inherit', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/payroll_inherit/payroll_inherit/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('payroll_inherit.listing', {
#             'root': '/payroll_inherit/payroll_inherit',
#             'objects': http.request.env['payroll_inherit.payroll_inherit'].search([]),
#         })

#     @http.route('/payroll_inherit/payroll_inherit/objects/<model("payroll_inherit.payroll_inherit"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('payroll_inherit.object', {
#             'object': obj
#         })
