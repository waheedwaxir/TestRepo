# -*- coding: utf-8 -*-
{
    'name': "Payslip Inherit",
    'summary': """
        Purpose of the module is when we create attendance then it will be to auto validate the work entry """,
    'author': "Waheed",
    'website': "http://www.xydata.com",
    'category': 'Uncategorized',
    'version': '15',
    'depends': ['base','hr_payroll','hr','hr_holidays'],
    'data': [
        'views/views.xml',
        'views/templates.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
}
