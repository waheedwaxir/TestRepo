# -*- coding: utf-8 -*-
from odoo import models, fields, api


class HrWorkEntryAttendance(models.Model):
    _inherit = 'hr.attendance'

    @api.model
    def create(self, vals):
        attendance = super(HrWorkEntryAttendance, self).create(vals)
        target_date = attendance.check_in.date()
        work_entry = self.env['hr.work.entry'].search([
            ('employee_id', '=', attendance.employee_id.id),
            ('state', '!=', 'validated'),
        ])
        for record in work_entry:
            if record.date_start.date() == target_date and record.work_entry_type_id.name == 'Attendance' and record.state == 'draft':
                record.write({'state': 'validated'})
        return attendance
